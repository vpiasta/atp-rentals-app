// ═════════════════════════════════════════════════════════════════════════════
//  LISTING.HTML — Add renewal button to renderView()
//
//  In listing.html, find the Links section in renderView():
//
//      ${rental.is_member && (rental.website_url || rental.booking_url || links.length) ? `
//
//  ADD this BEFORE that block:
// ═════════════════════════════════════════════════════════════════════════════

/*
        ${rental.is_member && isLoggedIn && isExpiringSoon(rental.membership_paid_until) ? `
        <div class="section" style="background:#fffbe6;border:1px solid #FFD700;border-radius:8px;margin:0.5rem 1.5rem;">
            <div style="padding:1rem;">
                <p style="font-size:0.88rem;color:#7a5c00;margin-bottom:0.8rem;">
                    ${isEs
                        ? `⚠️ Su membresía vence el <strong>${rental.membership_paid_until}</strong>. Renueve ahora para mantener su acceso.`
                        : `⚠️ Your membership expires on <strong>${rental.membership_paid_until}</strong>. Renew now to keep your access.`}
                </p>
                <button onclick="showRenewalForm()" class="qbtn" style="border-color:#b8860b;color:#7a5c00;background:#fffbe6;">
                    💳 ${isEs ? 'Renovar membresía' : 'Renew membership'}
                </button>
            </div>
        </div>` : ''}
*/

// ── Add isExpiringSoon helper to listing.html JavaScript ─────────────────────
/*
function isExpiringSoon(dateStr) {
    if (!dateStr) return false;
    const expiry = new Date(dateStr);
    const today  = new Date();
    const daysLeft = (expiry - today) / (1000*60*60*24);
    return daysLeft <= 30; // Show renewal notice within 30 days of expiry
}

function showRenewalForm() {
    // Redirect to pay.html with listing ID pre-filled
    window.location.href = `pay.html?id=${listingId}`;
}
*/


// ═════════════════════════════════════════════════════════════════════════════
//  ADMIN.HTML — Replace confirmReject() function
//  This version generates proper rejection emails and WhatsApp text files
// ═════════════════════════════════════════════════════════════════════════════

async function confirmReject(appId) {
    const reason = document.getElementById('reject-reason-'+appId).value;
    const note   = document.getElementById('reject-note-'+appId).value;
    if (!reason) { alert('Please select a rejection reason'); return; }
    if (!confirm('Send rejection email/WhatsApp text to applicant?')) return;

    // Determine rejection type
    const isPaymentIssue = reason.toLowerCase().includes('pago') || reason.toLowerCase().includes('comprobante');

    try {
        const res = await adminFetch('/api/admin/reject-application', {
            method: 'POST',
            body: JSON.stringify({
                application_id: appId,
                reason,
                custom_note:      note,
                is_payment_issue: isPaymentIssue
            })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);

        const card = document.getElementById('app-card-'+appId);
        if (card) {
            card.classList.replace('pending','rejected');
            card.querySelector('.app-status').textContent = 'REJECTED';
            card.querySelector('.app-status').className   = 'app-status rejected';
            card.querySelector('.app-actions')?.remove();
            card.querySelector('.reject-form')?.remove();
        }

        // If WhatsApp text was generated, offer download
        if (data.whatsapp_text) {
            const blob = new Blob([data.whatsapp_text], { type: 'text/plain;charset=utf-8' });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href     = url;
            a.download = `${data.property_name.replace(/[^a-zA-Z0-9]/g,'_')}_whatsapp.txt`;
            a.click();
            URL.revokeObjectURL(url);
            alert(`No email available — WhatsApp text file downloaded.\nSend it manually to: ${data.phone||'(no phone found)'}`);
        } else {
            alert('Rejection email sent successfully.');
        }

    } catch(err) { alert('Error: '+err.message); }
}

// Also replace approveApplication() to handle WhatsApp text download:
async function approveApplication(appId) {
    if (!confirm('Approve this application and send welcome email with auto-generated password?')) return;
    const resultEl = document.getElementById('approve-'+appId);
    resultEl.innerHTML = '⏳ Processing...';
    resultEl.classList.add('visible');
    try {
        const res  = await adminFetch('/api/admin/approve-application', {
            method: 'POST', body: JSON.stringify({ application_id: appId })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);

        resultEl.innerHTML = `
            <div style="color:#adf5ad;font-weight:700;margin-bottom:0.5rem;">✅ Application approved!</div>
            <div style="font-size:0.82rem;color:#ccc;">
                Password: <code style="background:#2c3e50;padding:2px 6px;border-radius:4px;">${data.password}</code><br>
                Membership until: <strong>${data.paid_until}</strong><br>
                Membership ID: <strong>${data.listing_id||'—'}</strong><br>
                ${data.email_sent ? '📧 Welcome email sent' : '📱 No email — WhatsApp text downloaded'}
            </div>`;

        // If no email, download WhatsApp text
        if (data.whatsapp_text) {
            const blob = new Blob([data.whatsapp_text], { type: 'text/plain;charset=utf-8' });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href     = url;
            a.download = `${(data.property_name||'member').replace(/[^a-zA-Z0-9]/g,'_')}_bienvenida.txt`;
            a.click();
            URL.revokeObjectURL(url);
        }

        const card = document.getElementById('app-card-'+appId);
        if (card) {
            card.classList.replace('pending','approved');
            card.querySelector('.app-status').textContent = 'APPROVED';
            card.querySelector('.app-status').className   = 'app-status approved';
            card.querySelector('.app-actions')?.remove();
            card.querySelector('.reject-form')?.remove();
        }
        await loadMembers();
        document.getElementById('stat-pending-apps').textContent =
            allApplications.filter(a=>a.status==='pending').length;
    } catch(err) { resultEl.innerHTML=`<span style="color:#ff7070;">Error: ${err.message}</span>`; }
}
