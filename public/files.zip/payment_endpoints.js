// ═════════════════════════════════════════════════════════════════════════════
//  ADD these endpoints to server.js before server.listen()
// ═════════════════════════════════════════════════════════════════════════════

// ── Multer for payment uploads (10MB) ────────────────────────────────────────
// Note: uploadDocs is already defined from the membership-apply endpoint
// If not, add: const uploadDocs = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10*1024*1024 } });

// ── POST /api/submit-payment ──────────────────────────────────────────────────
// Used by pay.html (expired/rejected members) and listing.html renewal button
app.post('/api/submit-payment',
    uploadDocs.fields([{ name: 'file_pago', maxCount: 1 }]),
    async (req, res) => {

    const { listing_id, duration_months, payment_method, contact_email, token } = req.body;
    if (!listing_id) return res.status(400).json({ error: 'Missing listing_id' });

    // If token provided, verify it (for listing page renewal)
    if (token) {
        try {
            const decoded = Buffer.from(token, 'base64').toString();
            const [tokenId] = decoded.split(':');
            if (tokenId !== String(listing_id))
                return res.status(403).json({ error: 'Invalid token' });
        } catch {
            return res.status(403).json({ error: 'Invalid token' });
        }
    }

    try {
        // Get listing info
        const { data: listing, error: listingError } = await supabase
            .from('listings')
            .select('id, name, province, email, email_member, phone, contact_name')
            .eq('id', listing_id)
            .single();
        if (listingError || !listing) return res.status(404).json({ error: 'Listing not found' });

        // Upload payment proof
        let documentPath = null;
        const file = req.files?.file_pago?.[0];
        if (file) {
            const safeName = file.originalname
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-zA-Z0-9._-]/g, '_')
                .replace(/_+/g, '_').toLowerCase();
            const fileName = `payments/${listing_id}/${Date.now()}-${safeName}`;
            const { error: uploadError } = await supabase.storage
                .from('member-documents')
                .upload(fileName, file.buffer, { contentType: file.mimetype, upsert: false });
            if (!uploadError) documentPath = fileName;
        }

        // Save payment submission to membership_applications
        const months = parseInt(duration_months) || 12;
        const amount = months === 24 ? 45 : 24;
        const { data: submission } = await supabase
            .from('membership_applications')
            .insert({
                listing_id:      parseInt(listing_id),
                property_name:   listing.name,
                province:        listing.province,
                contact_name:    listing.contact_name || '',
                contact_email:   contact_email || listing.email_member || listing.email || '',
                contact_phone:   listing.phone || '',
                membership_type: 'paid',
                duration_months: months,
                payment_method:  payment_method || 'transfer',
                documents:       documentPath ? [{ type:'comprobante_pago', path: documentPath, uploaded: new Date().toISOString(), mime: file?.mimetype, size: file?.size }] : null,
                notes:           'Payment renewal submission',
                status:          'pending'
            })
            .select().single();

        await logEvent('payment_submitted', {
            listing_id: parseInt(listing_id),
            duration_months: months,
            amount,
            has_proof: !!documentPath
        });

        // Notify admin
        const subject = `Comprobante de pago recibido: ${listing.name}`;
        const message = `
<html><body style="font-family:Arial,sans-serif;font-size:14px;">
<h2 style="color:#005ca9;">Comprobante de Pago Recibido</h2>
<table style="border-collapse:collapse;width:100%;max-width:500px;">
    <tr><td style="padding:6px;font-weight:bold;color:#555;">Hospedaje:</td><td style="padding:6px;">${listing.name}</td></tr>
    <tr style="background:#f5f5f5;"><td style="padding:6px;font-weight:bold;color:#555;">ID:</td><td style="padding:6px;">${listing_id}</td></tr>
    <tr><td style="padding:6px;font-weight:bold;color:#555;">Plan:</td><td style="padding:6px;">${months === 24 ? '2 años ($45)' : '1 año ($24)'}</td></tr>
    <tr style="background:#f5f5f5;"><td style="padding:6px;font-weight:bold;color:#555;">Método:</td><td style="padding:6px;">${payment_method||'transfer'}</td></tr>
    <tr><td style="padding:6px;font-weight:bold;color:#555;">Correo contacto:</td><td style="padding:6px;">${contact_email||'no proporcionado'}</td></tr>
    <tr style="background:#f5f5f5;"><td style="padding:6px;font-weight:bold;color:#555;">Comprobante:</td><td style="padding:6px;">${documentPath ? '✅ Recibido' : '❌ No adjuntado'}</td></tr>
</table>
<p style="margin-top:1rem;">
    <a href="https://trustedpanamastays.com/admin.html"
       style="background:#005ca9;color:white;padding:8px 16px;text-decoration:none;border-radius:5px;">
        Ver en Panel de Admin
    </a>
</p>
</body></html>`;

        const notifyPath = path.join(__dirname, 'public', 'notify.php');
        await execFileAsync('php', [notifyPath, subject, message, 'info@trustedpanamastays.com'], { timeout: 15000 })
            .catch(err => console.error('Payment notify failed:', err.message));

        res.json({ success: true, submission_id: submission?.id });

    } catch (err) {
        console.error('Payment submission error:', err.message);
        res.status(500).json({ error: err.message });
    }
});


// ═════════════════════════════════════════════════════════════════════════════
//  REPLACE /api/admin/approve-application with this updated version
//  Changes: generates correct rejection/approval messages with pay.html link
//  and WhatsApp text file for members without email
// ═════════════════════════════════════════════════════════════════════════════

// Helper: generate WhatsApp text
function generateWaText(app, type, password, paidUntil) {
    const listingUrl = `https://trustedpanamastays.com/listing.html?id=${app.listing_id}&lang=es`;
    const payUrl     = `https://trustedpanamastays.com/pay.html`;

    if (type === 'approved_trial') {
        return `Hola! Somos Trusted Panama Stays.

Su hospedaje *${app.property_name}* ha sido verificado y su membresía de prueba gratuita está activa hasta el *${paidUntil}*.

Sus datos de acceso:
🔗 URL: ${listingUrl}
🔑 Contraseña: ${password}

Con esta contraseña puede ingresar a su listado y agregar fotos, descripción y enlaces de reserva.

Recibirá un recordatorio 5 días antes del vencimiento.

¿Preguntas? info@trustedpanamastays.com`;
    }

    if (type === 'approved_paid') {
        return `Hola! Somos Trusted Panama Stays.

Su hospedaje *${app.property_name}* ha sido verificado y su membresía está activa hasta el *${paidUntil}*.

Sus datos de acceso:
🔗 URL: ${listingUrl}
🔑 Contraseña: ${password}

¿Preguntas? info@trustedpanamastays.com`;
    }

    if (type === 'rejected_payment') {
        return `Hola! Somos Trusted Panama Stays.

Hemos revisado su solicitud para *${app.property_name}*.

Sus documentos de identidad son válidos ✅
Sin embargo, el comprobante de pago requiere revisión ⚠️

Su número de membresía es: *${app.listing_id}*

Para enviar el comprobante correcto, visite:
${payUrl}

Al realizar el pago, incluya el nombre de su hospedaje y provincia en el campo MENSAJE.

¿Preguntas? info@trustedpanamastays.com`;
    }

    return '';
}

// Helper: generate approval/rejection email HTML
function generateEmailHtml(app, type, password, paidUntil, rejectReason) {
    const listingUrl = `https://trustedpanamastays.com/listing.html?id=${app.listing_id}&lang=es`;
    const payUrl     = `https://trustedpanamastays.com/pay.html`;

    const header = `<div style="background:linear-gradient(135deg,#005ca9,#00a859);padding:1.5rem;border-radius:10px;margin-bottom:1.5rem;">
        <h1 style="color:white;margin:0;font-size:1.4rem;">Trusted Panama Stays</h1>
    </div>`;
    const footer = `<hr style="border:none;border-top:1px solid #e1e5e9;margin:1.5rem 0;">
        <p style="color:#888;font-size:0.78rem;">Trusted Panama Stays · Tuscany Real Estates SA · RUC 1401220-1-627960 DV21</p>`;

    if (type === 'approved_trial' || type === 'approved_paid') {
        const planText = type==='approved_trial' ? 'prueba gratuita de 30 días' : (app.duration_months===24?'membresía de 2 años':'membresía de 1 año');
        return `<html><body style="font-family:Arial,sans-serif;font-size:14px;color:#111;max-width:600px;">
            ${header}
            <p>Estimado/a <strong>${app.contact_name}</strong>,</p>
            <p>Su solicitud ha sido <strong style="color:#00a859;">aprobada</strong>. Su ${planText} para <strong>${app.property_name}</strong> está activa hasta el <strong>${paidUntil}</strong>.</p>
            <h3 style="color:#005ca9;margin-top:1.2rem;">Sus datos de acceso:</h3>
            <table style="border:1px solid #e1e5e9;border-radius:8px;background:#f8f9fa;width:100%;margin-bottom:1rem;">
                <tr><td style="padding:8px;font-weight:bold;">URL:</td><td style="padding:8px;"><a href="${listingUrl}">${listingUrl}</a></td></tr>
                <tr><td style="padding:8px;font-weight:bold;">Contraseña:</td><td style="padding:8px;font-family:monospace;font-size:1.1rem;"><strong>${password}</strong></td></tr>
                <tr><td style="padding:8px;font-weight:bold;">N° membresía:</td><td style="padding:8px;font-family:monospace;"><strong>${app.listing_id}</strong></td></tr>
            </table>
            <p style="color:#666;font-size:0.88rem;">Le recomendamos cambiar su contraseña después del primer acceso.</p>
            ${type==='approved_trial' ? `<p style="background:#fffbe6;padding:1rem;border-radius:6px;border:1px solid #FFD700;margin-top:1rem;">
                <strong>⚠️ Recordatorio:</strong> Su prueba vence el <strong>${paidUntil}</strong>. Recibirá un recordatorio 5 días antes.<br>
                Para renovar: <a href="${payUrl}">${payUrl}</a> · N° membresía: <strong>${app.listing_id}</strong>
            </p>` : ''}
            <p style="margin-top:1rem;">Para editar su listado, visite el enlace y haga clic en <strong>🔐 Acceso</strong>.</p>
            <p>¿Preguntas? <a href="mailto:info@trustedpanamastays.com">info@trustedpanamastays.com</a></p>
            ${footer}
        </body></html>`;
    }

    if (type === 'rejected_payment') {
        return `<html><body style="font-family:Arial,sans-serif;font-size:14px;color:#111;max-width:600px;">
            ${header}
            <p>Estimado/a <strong>${app.contact_name}</strong>,</p>
            <p>Hemos revisado su solicitud para <strong>${app.property_name}</strong>.</p>
            <p>✅ Sus documentos de identidad son válidos.</p>
            <div style="background:#fffbe6;border:1px solid #FFD700;border-radius:8px;padding:1rem;margin:1rem 0;">
                <strong>⚠️ Comprobante de pago:</strong> ${rejectReason||'El comprobante recibido no corresponde al monto de membresía o requiere revisión.'}
            </div>
            <p>Para completar su membresía, envíe el comprobante correcto:</p>
            <table style="border:1px solid #e1e5e9;border-radius:8px;background:#f8f9fa;width:100%;margin-bottom:1rem;">
                <tr><td style="padding:8px;font-weight:bold;">N° membresía:</td><td style="padding:8px;font-family:monospace;font-size:1.1rem;"><strong>${app.listing_id}</strong></td></tr>
                <tr><td style="padding:8px;font-weight:bold;">Página de pago:</td><td style="padding:8px;"><a href="${payUrl}">${payUrl}</a></td></tr>
            </table>
            <p style="font-size:0.85rem;color:#666;">Al realizar el pago, incluya el nombre de su hospedaje y provincia en el campo <strong>MENSAJE</strong>.</p>
            <p>¿Preguntas? <a href="mailto:info@trustedpanamastays.com">info@trustedpanamastays.com</a></p>
            ${footer}
        </body></html>`;
    }

    // Generic rejection
    return `<html><body style="font-family:Arial,sans-serif;font-size:14px;color:#111;max-width:600px;">
        ${header}
        <p>Estimado/a <strong>${app.contact_name}</strong>,</p>
        <p>Lamentablemente no podemos aprobar su solicitud para <strong>${app.property_name}</strong>.</p>
        <div style="background:#fde8e8;border:1px solid #ffcccc;border-radius:8px;padding:1rem;margin:1rem 0;">
            <strong>${rejectReason||'Documentos inválidos o incompletos.'}</strong>
        </div>
        <p>Puede volver a aplicar en: <a href="https://trustedpanamastays.com/join.html">trustedpanamastays.com/join.html</a></p>
        <p>¿Preguntas? <a href="mailto:info@trustedpanamastays.com">info@trustedpanamastays.com</a></p>
        ${footer}
    </body></html>`;
}


// ═════════════════════════════════════════════════════════════════════════════
//  REPLACE /api/admin/reject-application with this updated version
//  Handles: email sending OR WhatsApp text generation, payment-specific rejection
// ═════════════════════════════════════════════════════════════════════════════
app.post('/api/admin/reject-application', requireAdmin, async (req, res) => {
    const { application_id, reason, custom_note, is_payment_issue } = req.body;
    if (!application_id || !reason) return res.status(400).json({ error: 'Missing fields' });

    const { data: app, error: appError } = await supabase
        .from('membership_applications')
        .select('*')
        .eq('id', application_id)
        .single();
    if (appError || !app) return res.status(404).json({ error: 'Not found' });

    const fullReason = `${reason}${custom_note ? '. '+custom_note : ''}`;

    // Update application status
    await supabase.from('membership_applications').update({
        status:      'rejected',
        notes:       `Razón: ${fullReason}`,
        reviewed_at: new Date().toISOString(),
        reviewed_by: 'admin'
    }).eq('id', application_id);

    await logEvent('application_rejected', { application_id, reason, is_payment_issue });

    const hasEmail = !!(app.contact_email && app.contact_email.includes('@'));
    let emailSent  = false;
    let waText     = null;

    // Determine message type
    const msgType = is_payment_issue ? 'rejected_payment' : 'rejected_other';
    const emailHtml = generateEmailHtml(app, msgType, null, null, fullReason);
    const waMsg     = generateWaText({ ...app, listing_id: app.listing_id }, msgType, null, null);

    if (hasEmail) {
        // Send email
        const notifyPath = path.join(__dirname, 'public', 'notify.php');
        try {
            await execFileAsync('php', [
                notifyPath,
                `Solicitud de membresía — ${app.property_name}`,
                emailHtml,
                app.contact_email
            ], { timeout: 15000 });
            emailSent = true;
        } catch (err) {
            console.error('Rejection email failed:', err.message);
            // Fall back to WhatsApp text
            waText = waMsg;
        }
    } else {
        // No email — generate WhatsApp text
        waText = waMsg;
    }

    // Get phone number for WhatsApp
    const phone = app.contact_phone?.replace(/[^\d]/g,'').substring(0,8) || null;

    res.json({
        success:        true,
        email_sent:     emailSent,
        whatsapp_text:  waText,
        property_name:  app.property_name,
        phone
    });
});


// ═════════════════════════════════════════════════════════════════════════════
//  REPLACE /api/admin/approve-application with this updated version
//  Handles: email sending OR WhatsApp text generation
// ═════════════════════════════════════════════════════════════════════════════
app.post('/api/admin/approve-application', requireAdmin, async (req, res) => {
    const bcrypt = require('bcrypt');
    const { application_id } = req.body;
    if (!application_id) return res.status(400).json({ error: 'Missing application_id' });

    const { data: app, error: appError } = await supabase
        .from('membership_applications')
        .select('*')
        .eq('id', application_id)
        .single();
    if (appError || !app) return res.status(404).json({ error: 'Application not found' });

    try {
        const isTrial  = app.membership_type === 'trial';
        let listingId  = app.listing_id;

        // Check existing trial/membership for trial applications
        if (isTrial && listingId) {
            const { data: existing } = await supabase
                .from('listings')
                .select('is_trial, trial_started_at, is_member')
                .eq('id', listingId)
                .single();
            if (existing?.trial_started_at || existing?.is_member) {
                await supabase.from('membership_applications').update({
                    status:      'rejected',
                    notes:       'Rechazado automáticamente: ya tuvo prueba gratuita o membresía.',
                    reviewed_at: new Date().toISOString(),
                    reviewed_by: 'system'
                }).eq('id', application_id);
                return res.status(400).json({
                    error: 'Este hospedaje ya tuvo una prueba gratuita o membresía. Solicitud rechazada automáticamente.'
                });
            }
        }

        // Generate password
        const chars    = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        const password = Array.from({ length: 10 }, () =>
            chars[Math.floor(Math.random() * chars.length)]).join('');
        const hash = await bcrypt.hash(password, 10);

        // Calculate dates
        const paidUntil = new Date();
        if (isTrial) paidUntil.setDate(paidUntil.getDate() + 30);
        else paidUntil.setFullYear(paidUntil.getFullYear() + (app.duration_months===24?2:1));
        const paidUntilStr = paidUntil.toISOString().split('T')[0];

        // Generate slug
        const slug = app.property_name
            .toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

        // Update listing
        if (listingId) {
            await supabase.from('listings').update({
                is_member:             true,
                is_trial:              isTrial,
                trial_started_at:      isTrial ? new Date().toISOString() : null,
                membership_paid_until: paidUntilStr,
                member_password:       hash,
                contact_name:          app.contact_name,
                email_member:          app.contact_email,
                phone_member:          app.contact_phone,
                slug,
                invitation_status:     'member',
                verified_at:           new Date().toISOString(),
                verified_by:           'admin'
            }).eq('id', listingId);
        }

        // Log invoice for paid plans
        if (!isTrial) {
            const amount = app.duration_months===24?45:24;
            const itbms  = parseFloat((amount*0.07).toFixed(2));
            await supabase.from('event_log').insert({
                event_type: 'invoice_pending',
                event_data: {
                    application_id, listing_id: listingId,
                    property_name: app.property_name,
                    contact_name:  app.contact_name,
                    contact_email: app.contact_email,
                    ruc: null, amount, itbms,
                    total: parseFloat((amount+itbms).toFixed(2)),
                    plan: app.duration_months+' months',
                    payment_method: app.payment_method,
                    date: new Date().toISOString()
                },
                created_at: new Date().toISOString()
            });
        }

        // Update application status
        await supabase.from('membership_applications').update({
            status: 'approved', reviewed_at: new Date().toISOString(), reviewed_by: 'admin'
        }).eq('id', application_id);

        // Generate messages
        const msgType   = isTrial ? 'approved_trial' : 'approved_paid';
        const emailHtml = generateEmailHtml({ ...app, listing_id: listingId }, msgType, password, paidUntilStr);
        const waMsg     = generateWaText({ ...app, listing_id: listingId }, msgType, password, paidUntilStr);

        const hasEmail = !!(app.contact_email && app.contact_email.includes('@'));
        let emailSent  = false;
        let waText     = null;

        if (hasEmail) {
            const notifyPath = path.join(__dirname, 'public', 'notify.php');
            try {
                await execFileAsync('php', [
                    notifyPath,
                    `Membresía aprobada — ${app.property_name}`,
                    emailHtml,
                    app.contact_email
                ], { timeout: 15000 });
                emailSent = true;
            } catch (err) {
                console.error('Welcome email failed:', err.message);
                waText = waMsg;
            }
        } else {
            waText = waMsg;
        }

        const phone = app.contact_phone?.replace(/[^\d]/g,'').substring(0,8) || null;

        await logEvent('application_approved', {
            application_id, listing_id: listingId,
            membership_type: app.membership_type, paid_until: paidUntilStr
        });

        res.json({
            success: true, password, paid_until: paidUntilStr,
            listing_id: listingId, property_name: app.property_name,
            email_sent: emailSent, whatsapp_text: waText, phone
        });

    } catch (err) {
        console.error('Approve error:', err.message);
        res.status(500).json({ error: err.message });
    }
});
